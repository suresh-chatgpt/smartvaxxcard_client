package com.covid.vaxxcard.smart_vaxx_card_client

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
