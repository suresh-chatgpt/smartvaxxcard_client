class ThemeColors {
  static const BLUE = 0xFF4285F4;
  static const RED = 0xFFDB4437;
  static const GREEN = 0xFF0F9D58;
  static const WHITE = 0xFFFFFFFF;
  static const BLACK = 0xFF000000;
  static const VIOLET = 0xFF710173;
  static const ORANGE = 0xFFFF6700;
  static const DARK_VIOLET = 0xFF43025A;
  static const DARK_BLUE = 0xFF1F72FB;
  static const DARK_GREEN = 0xFF03542D;
  static const GREY = 0xFF605C5C;
}
