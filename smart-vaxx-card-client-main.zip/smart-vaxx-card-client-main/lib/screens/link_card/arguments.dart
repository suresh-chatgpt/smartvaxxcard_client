class LinkCardScreenArguments {
  const LinkCardScreenArguments(this.cardId);
  final String cardId;
}
