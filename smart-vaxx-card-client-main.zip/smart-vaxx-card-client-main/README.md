# smart-vaxx-card-client

Client app for Smart Vaxx Card project

### Features:

-   Phone Authentication
-   Live Global & Country Covid Statistics
-   Upload Vaccination cards
-   View & share Vaccination cards
-   View all Covid centers

### Tech stack:

-   Flutter & dart
-   Firebase

Tested on Android (iOS should work because it's Flutter :sunglasses:)
